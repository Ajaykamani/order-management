package com.cts.training.SeriesModelService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SeriesModelServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(SeriesModelServiceApplication.class, args);
	}

}
